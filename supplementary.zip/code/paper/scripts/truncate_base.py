"""Base-model evals re-graded as if generated with the 1024-token training/snapshot budget: outputs/base-1024/<model>/eval@K/summary.json."""

import gzip
import json
import sys
from pathlib import Path

from transformers import AutoTokenizer

from llmbo.models import MODELS
from llmbo.tasks import extract, grade

RUNS = Path("outputs/runs")
OUT = Path("outputs/base-1024")
BENCHMARKS = ["gsm8k", "math500", "aime24", "amc23", "minerva", "olympiad"]
BUDGET = 1024


def truncate(tokenizer, completion: str, correct: bool, answer: str) -> tuple[bool, bool]:
    """(correct under the budget, was truncated); greedy/sampled prefixes are unchanged by a shorter max_tokens."""
    ids = tokenizer(completion, add_special_tokens=False)["input_ids"]
    if len(ids) <= BUDGET:
        return correct, False
    return grade(extract(tokenizer.decode(ids[:BUDGET])), answer), True


for name in sys.argv[1:]:
    spec = MODELS[name]
    tokenizer = AutoTokenizer.from_pretrained(spec.hf_id)
    for k in (1, 4):
        summary = {}
        for bench in BENCHMARKS:
            result = json.load(gzip.open(RUNS / spec.family / name / "base" / f"eval@{k}" / f"{bench}.json.gz"))
            n_correct = n_truncated = n_total = 0
            for record in result["records"]:
                completions = [record["completion"]] if k == 1 else record["completions"]
                corrects = [record["correct"]] if k == 1 else record["correct"]
                for completion, correct in zip(completions, corrects):
                    ok, cut = truncate(tokenizer, completion, correct, record["answer"])
                    n_correct += ok
                    n_truncated += cut
                    n_total += 1
            summary[bench] = dict(accuracy=n_correct / n_total, n_correct=n_correct, truncated=n_truncated, n=n_total, accuracy_4096=result["accuracy"])
            print(name, k, bench, f"{result['accuracy']:.3f} -> {n_correct / n_total:.3f}  truncated {n_truncated}/{n_total}", flush=True)
        out = OUT / name / f"eval@{k}"
        out.mkdir(parents=True, exist_ok=True)
        (out / "summary.json").write_text(json.dumps(summary, indent=1))
