"""Benchmark tasks: math-verify grading plus one callable `Task` per benchmark."""

import ast
import re
import signal
from contextlib import contextmanager
from typing import Iterator, Protocol

from datasets import Dataset, concatenate_datasets, load_dataset
from huggingface_hub import hf_hub_download
from math_verify import parse, verify
from math_verify.errors import TimeoutException


@contextmanager
def grading_deadline(seconds: float = 5) -> Iterator[None]:
    """Re-firing SIGALRM around math-verify: its own one-shot alarm is lost when it lands inside a __del__ (exception ignored), leaving sympy unbounded."""

    def raise_timeout(*_: object) -> None:
        raise TimeoutException("grading timed out")

    previous = signal.signal(signal.SIGALRM, raise_timeout)
    signal.setitimer(signal.ITIMER_REAL, seconds, 1)
    try:
        yield
    except TimeoutException:
        pass
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        signal.signal(signal.SIGALRM, previous)


def extract(completion: str) -> str | None:
    """Final answer as math-verify extracts it: last \\boxed{}, else last math expression."""
    with grading_deadline():
        parsed = parse(completion.replace("\\boxed{}", ""), parsing_timeout=None)
        return parsed[-1] if parsed else None
    return None


def grade(prediction: str | None, reference: str) -> bool:
    """Symbolic/numeric equivalence via math-verify (`reference` is raw answer text, not a completion)."""
    if prediction is None:
        return False
    # spell out `4.5e33` as `4.5\times10^{33}`; math-verify would otherwise read it as 4.5*e*33
    sci = re.compile(r"(\d)[eE]([-+]?\d+)\b")
    with grading_deadline():
        return verify(
            parse(f"${sci.sub(r'\1\\times10^{\2}', reference)}$", parsing_timeout=None),
            parse(f"${sci.sub(r'\1\\times10^{\2}', prediction)}$", parsing_timeout=None),
            timeout_seconds=None,
        )
    return False


def reward(completions: list[str], answer: list[str], **kwargs) -> list[float]:
    """TRL reward function over raw-text completions: 1.0 if the final answer matches gold, else 0.0."""
    return [float(grade(extract(c), a)) for c, a in zip(completions, answer)]


def load_from_hf(path: str, name: str | None = None, split: str = "test") -> Dataset:
    """`load_dataset` narrowed to `Dataset`: with a `split` it never returns a dict or iterable."""
    ds = load_dataset(path, name, split=split)
    assert isinstance(ds, Dataset)
    return ds


class Task(Protocol):
    def __call__(self, split: str = "test") -> Dataset:
        """Load a dataset with columns `question` and `answer`."""
        ...


class SimpleRLZoo(Task):
    """SimpleRL-Zoo difficulty tier (GSM8K + MATH train, split by MATH level); its `test` split is MATH-500."""

    def __init__(self, config: str):
        self.config = config

    def __call__(self, split: str = "test") -> Dataset:
        # hub download (cache hit under HF_HUB_OFFLINE) instead of remote `data_files`, which never resolves offline
        parquet = hf_hub_download("hkust-nlp/SimpleRL-Zoo-Data", f"{self.config}/{split}.parquet", repo_type="dataset")
        ds = load_dataset("parquet", data_files=parquet, split="train")
        assert isinstance(ds, Dataset)
        ds = ds.map(
            lambda r: {
                "question": r["extra_info"]["question"],
                "answer": r["extra_info"]["answer"],
            }
        )
        # two level-5 problems ship without a gold answer; drop them
        return ds.select_columns(["question", "answer"]).filter(
            lambda r: bool(r["answer"])
        )


class GSM8K(Task):
    @staticmethod
    def format_answer(answer: str) -> str:
        return answer.split("####")[-1].strip()

    def __call__(self, split: str = "test") -> Dataset:
        ds = load_from_hf("openai/gsm8k", "main", split)
        return ds.map(lambda r: {"answer": self.format_answer(r["answer"])})


class Math(Task):
    """Full Hendrycks MATH (7500 train / 5000 test, all levels); the gold is the solution's last \\boxed{}."""

    SUBJECTS = ["algebra", "counting_and_probability", "geometry", "intermediate_algebra", "number_theory", "prealgebra", "precalculus"]

    def __call__(self, split: str = "test") -> Dataset:
        ds = concatenate_datasets([load_from_hf("EleutherAI/hendrycks_math", subject, split) for subject in self.SUBJECTS])
        ds = ds.rename_column("problem", "question")
        ds = ds.map(lambda r: {"answer": extract(r["solution"]) or ""})
        return ds.select_columns(["question", "answer"]).filter(lambda r: bool(r["answer"]))


class Math500(Task):
    def __call__(self, split: str = "test") -> Dataset:
        ds = load_from_hf("HuggingFaceH4/MATH-500", split=split)
        ds = ds.rename_column("problem", "question")
        return ds.select_columns(["question", "answer"])


class AIME24(Task):
    @staticmethod
    def format_answer(solution: str) -> str:
        return extract(solution) or ""

    def __call__(self, split: str = "test") -> Dataset:
        ds = load_from_hf("math-ai/aime24", split=split)
        ds = ds.rename_columns({"problem": "question", "solution": "answer"})
        ds = ds.select_columns(["question", "answer"])
        return ds.map(lambda r: {"answer": self.format_answer(r["answer"])})


class AMC23(Task):
    def __call__(self, split: str = "test") -> Dataset:
        ds = load_from_hf("math-ai/amc23", split=split)
        return ds.select_columns(["question", "answer"])


class Minerva(Task):
    def __call__(self, split: str = "test") -> Dataset:
        ds = load_from_hf("math-ai/minervamath", split=split)
        return ds.select_columns(["question", "answer"])


class OlympiadBench(Task):
    @staticmethod
    def format_answer(final_answer: str | list[str]) -> str:
        """`final_answer` is a (possibly stringified) list like ['$2^{1009}$']."""
        return ast.literal_eval(str(final_answer))[0]

    def __call__(self, split: str = "test") -> Dataset:
        ds = load_from_hf("math-ai/olympiadbench", split=split)
        ds = ds.rename_column("final_answer", "answer")
        ds = ds.select_columns(["question", "answer"])
        return ds.map(lambda r: {"answer": self.format_answer(r["answer"])})


TASKS: dict[str, Task] = {
    "easy": SimpleRLZoo("simplelr_qwen_gsm8k_level1"),  # GSM8K + MATH level 1
    "medium": SimpleRLZoo("simplelr_qwen_level1to4"),
    "hard": SimpleRLZoo("simplelr_qwen_level3to5"),
    "gsm8k": GSM8K(),  # train split = GSM8K train (7473), same distribution as its test set
    "math": Math(),  # train split = MATH train (7500), same level/subject mix as MATH-500
    "math500": Math500(),
    "aime24": AIME24(),
    "amc23": AMC23(),
    "minerva": Minerva(),
    "olympiad": OlympiadBench(),
}
