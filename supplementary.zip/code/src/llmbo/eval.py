"""Test-set eval of a model, optionally with a trained adapter, on one or more tasks with vLLM: greedy by default, or K sampled completions per question (--samples K)."""

import argparse
import gzip
import json
import os
import resource
import subprocess
import sys
import time
import traceback
from collections.abc import Callable
from pathlib import Path

from datasets import Dataset
from huggingface_hub import hf_hub_download

from llmbo.models import MODELS, Model
from llmbo.tasks import TASKS, extract, grade


def evaluate(
    generate: Callable[[list[str]], list[list[str]]],
    spec: Model,
    dataset: Dataset,
) -> list[dict]:
    """One record per example: completion, extracted prediction, answer, and correctness; lists of each when sampling K > 1."""
    completions = generate([spec.prompt(q) for q in dataset["question"]])
    records = []
    for example, samples in zip(dataset.to_list(), completions):
        predicted = [extract(c) for c in samples]
        correct = [grade(p, example["answer"]) for p in predicted]
        graded = (
            dict(predicted=predicted[0], correct=correct[0], completion=samples[0])
            if len(samples) == 1
            else dict(predicted=predicted, correct=correct, completions=samples)
        )
        records.append(example | graded)
    return records


def summarize(records: list[dict]) -> dict:
    """Greedy: accuracy over questions. Sampled: accuracy = mean correctness over every completion (pass@1, GRPO's reward), pass_any = any of the K."""
    if not isinstance(records[0]["correct"], list):
        return {
            "accuracy": sum(r["correct"] for r in records) / len(records),
            "n_correct": sum(r["correct"] for r in records),
            "n": len(records),
            "unparsed": sum(r["predicted"] is None for r in records),
        }
    k = len(records[0]["correct"])
    correct = sum(sum(r["correct"]) for r in records)
    return {
        "accuracy": correct / (k * len(records)),
        "n_correct": correct,
        "n": len(records),
        "samples": k,
        "pass_any": sum(any(r["correct"]) for r in records) / len(records),
        "unparsed": sum(p is None for r in records for p in r["predicted"]),
    }


def eval_dir(out_dir: Path, samples: int = 1) -> Path:
    """Where the K-sample eval of a snapshot/baseline lives: <out_dir>/eval@K (K=1 greedy)."""
    return out_dir / f"eval@{samples}"


def write_result(
    out_dir: Path, task: str, stats: dict, records: list[dict], samples: int = 1, **meta
) -> None:
    """<out_dir>/eval@K/<task>.json.gz holds every record; eval@K/summary.json accumulates the per-task stats."""
    out_dir = eval_dir(out_dir, samples)
    out_dir.mkdir(parents=True, exist_ok=True)
    with gzip.open(out_dir / f"{task}.json.gz", "wt", compresslevel=9) as f:
        json.dump({"task": task, **meta, **stats, "records": records}, f)
    summary_path = out_dir / "summary.json"
    summary = json.loads(summary_path.read_text()) if summary_path.exists() else {}
    summary[task] = stats
    summary_path.write_text(json.dumps(summary, indent=1))


def resolve_run(
    model: str | None, adapter: str | None, out_dir: str | None
) -> tuple[str, Path]:
    """Snapshot evals live in the snapshot dir (model read from the run's run.json); baselines are the `base` adapter: out-dir/<family>/<model>/base."""
    if adapter:
        run_dir = Path(adapter).parent.parent
        model = model or json.loads((run_dir / "run.json").read_text())["model"]
        return model, Path(out_dir) if out_dir else Path(adapter)
    if not model:
        raise SystemExit("--model is required without --adapter")
    return model, Path(out_dir or "outputs/runs") / MODELS[model].family / model / "base"


def lora_weights(snapshot: str) -> Path:
    """The run's final_adapter PEFT export, which matches the last snapshot only."""
    snapshot_dir = Path(snapshot)
    run_dir = snapshot_dir.parent.parent
    if snapshot_dir != sorted(run_dir.glob("snapshots/step-*"))[-1]:
        raise SystemExit(f"{snapshot} is not the run's last snapshot, so final_adapter does not match it")
    return run_dir / "final_adapter"


def lora_engine_args(adapters: list[str]) -> dict:
    """vLLM's LoRA kernels need max_lora_rank >= 8 even for a rank-2 adapter."""
    ranks = [
        json.loads((lora_weights(a) / "adapter_config.json").read_text())["r"] for a in adapters
    ]
    return dict(enable_lora=True, max_lora_rank=max(8, *ranks))


def usage(seconds: float) -> dict:
    """Wall time, host RAM peak, and the GPU's name / VRAM as reported by nvidia-smi."""
    query = "--query-gpu=name,memory.used,memory.total"
    gpu = (
        subprocess.run(
            ["nvidia-smi", query, "--format=csv,noheader,nounits"],
            capture_output=True,
            text=True,
            check=True,
        )
        .stdout.strip()
        .split("\n")[0]
    )
    name, used_mib, total_mib = (v.strip() for v in gpu.split(","))
    return {
        "seconds": round(seconds, 1),
        "host_ram_gb": round(
            resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 2**20, 2
        ),
        "gpu": name,
        "vram_used_gb": round(int(used_mib) / 1024, 2),
        "vram_total_gb": round(int(total_mib) / 1024, 2),
    }


def main() -> None:
    from vllm import LLM, SamplingParams
    from vllm.lora.request import LoRARequest

    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--model", choices=MODELS, help="defaults to the adapter's run.json"
    )
    parser.add_argument(
        "--adapters",
        nargs="+",
        help="snapshot dirs (<run>/snapshots/step-N); each one's results go into that dir",
    )
    parser.add_argument("--tasks", nargs="+", choices=TASKS, required=True)
    parser.add_argument("--split", default="test", help="dataset split; a non-test split writes <task>-<split>.json.gz (train-set eval of a run's own tier)")
    parser.add_argument("--max-tokens", type=int, default=4096)
    parser.add_argument(
        "--samples", type=int, default=1, help="completions per question; >1 samples at --temperature; results go under eval@K"
    )
    parser.add_argument("--temperature", type=float, default=1.0, help="sampling temperature when --samples > 1 (GRPO rollouts use 1.0)")
    parser.add_argument("--tp", type=int, default=1, help="tensor parallel size (GPUs)")
    parser.add_argument(
        "--out-dir",
        help="baselines: <out-dir>/<family>/<model>/base/eval@K/<task>.json.gz (default outputs/runs)",
    )
    parser.add_argument(
        "--show", type=int, default=0, help="print first N completions per task"
    )
    parser.add_argument(
        "--skip-existing",
        action="store_true",
        help="leave already-written eval@K/<task>.json.gz alone",
    )
    args = parser.parse_args()

    # one engine load serves every adapter, so they must all sit on the same base model
    adapters = args.adapters or [None]
    runs = [resolve_run(args.model, adapter, args.out_dir) for adapter in adapters]
    models = {model for model, _ in runs}
    if len(models) > 1:
        raise SystemExit(f"adapters span several base models: {sorted(models)}")
    args.model = models.pop()
    spec = MODELS[args.model]
    config = json.loads(Path(hf_hub_download(spec.hf_id, "config.json")).read_text())
    text_config = config.get("text_config", config)

    # 4k-context models (Qwen2.5-Math, DeepSeek) can't take prompt + 4096 new tokens; shrink the budget
    max_model_len = min(args.max_tokens + 1024, text_config["max_position_embeddings"])
    max_tokens = max_model_len - 1024

    # multimodal bases (Ministral 3): skip the vision tower, whose xformers kernels are missing here
    multimodal: dict = (
        {"limit_mm_per_prompt": {"image": 0}} if "vision_config" in config else {}
    )

    lora = lora_engine_args(args.adapters) if args.adapters else {}

    llm = LLM(
        model=spec.hf_id,
        max_model_len=max_model_len,
        gpu_memory_utilization=0.9,
        tensor_parallel_size=args.tp,
        **multimodal,
        **lora,
    )
    sampled = args.samples > 1
    sampling = SamplingParams(
        n=args.samples,
        temperature=args.temperature if sampled else 0.0,
        max_tokens=max_tokens,
        stop=list(spec.prompt.stop),
    )
    # results of a non-test split get their own name so they never shadow the test eval (the tiers' `test` is MATH-500)
    datasets = {task if args.split == "test" else f"{task}-{args.split}": TASKS[task](args.split) for task in args.tasks}

    for index, (adapter, (_, out_dir)) in enumerate(zip(adapters, runs)):
        lora_request = (
            LoRARequest(f"adapter{index}", index + 1, str(lora_weights(adapter).resolve()))
            if adapter
            else None
        )
        generate = lambda prompts: [
            [c.text for c in o.outputs]
            for o in llm.generate(prompts, sampling, lora_request=lora_request)
        ]

        for task, dataset in datasets.items():
            out_path = eval_dir(out_dir, args.samples) / f"{task}.json.gz"
            if args.skip_existing and out_path.exists():
                print(f"skipping {out_path}")
                continue

            start = time.perf_counter()
            records = evaluate(generate, spec, dataset)
            stats = summarize(records) | usage(time.perf_counter() - start)

            for record in records[: args.show]:
                print("=" * 80)
                print(f"question:  {record['question']}")
                print(f"completion:\n{record.get('completion', record.get('completions', [''])[0])}")
                print(f"predicted: {record['predicted']}   answer: {record['answer']}")
            print(
                f"[{args.model}/{task}] accuracy: {stats['accuracy']:.4f} "
                f"({stats['n_correct']}/{stats['n'] * stats.get('samples', 1)}), unparsed: {stats['unparsed']}, "
                f"{stats['seconds']}s, {stats['vram_used_gb']}/{stats['vram_total_gb']} GB on {stats['gpu']}"
            )

            write_result(
                out_dir, task, stats, records, args.samples, model=spec.hf_id, adapter=adapter, temperature=sampling.temperature, split=args.split, max_tokens=max_tokens
            )
            print(f"wrote {out_path}")


if __name__ == "__main__":
    # vLLM's engine teardown can hang the interpreter at exit, even after a crash; skip it
    try:
        main()
        code = 0
    except SystemExit as exc:
        code = exc.code if isinstance(exc.code, int) else 1 if exc.code else 0
        if isinstance(exc.code, str):
            print(exc.code, file=sys.stderr)
    except BaseException:
        traceback.print_exc()
        code = 1
    sys.stdout.flush()
    sys.stderr.flush()
    os._exit(code)
