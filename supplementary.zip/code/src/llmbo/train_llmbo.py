"""LlMBO training of TinyLoRA: train_bo's objective searched by turbo.search."""

from llmbo import train_bo, turbo
from llmbo.adapters import TinyLoRA


def main() -> None:
    args = turbo.add_arguments(train_bo.argument_parser()).parse_args()
    train_bo.run(args, TinyLoRA, turbo.search, "llmbo")


if __name__ == "__main__":
    main()
