"""CPU tests: the GP and `turbo.search` on a toy objective; `train_bo.run` with unsloth (conftest), vLLM and CUDA faked."""

import importlib.machinery
import json
import os
import signal
import sys
import types
from pathlib import Path

import pytest
import torch
from datasets import Dataset

vllm = types.ModuleType("vllm")
vllm.__spec__ = importlib.machinery.ModuleSpec("vllm", None)


class FakeSamplingParams:
    def __init__(self, **kwargs):
        self.n = 1
        self.__dict__.update(kwargs)


vllm.SamplingParams = FakeSamplingParams  # type: ignore[attr-defined]
sys.modules["vllm"] = vllm

import unsloth  # noqa: E402  conftest stub
from llmbo import bo, train_bo, turbo  # noqa: E402
from llmbo.adapters import TinyLoRA  # noqa: E402
from llmbo.models import MODELS  # noqa: E402

SMALL = ["--theta-range", "0.1", "--batch", "1", "--n-baseline", "2", "--n-sobol", "2", "--n-evals", "4"]


def search_args(*extra: str):
    return turbo.add_arguments(bo.argument_parser()).parse_args([*SMALL, *extra])


def test_fixed_noise_gp_denoises_toward_the_optimum():
    torch.manual_seed(0)
    X = torch.linspace(-0.1, 0.1, 25, dtype=torch.float64)[:, None]
    truth = 0.8 - 20 * (X - 0.03) ** 2
    Y = truth + 0.02 * torch.randn_like(truth)
    gp = bo.fit_gp([dict(theta=x.tolist(), value=y.item(), sem=0.02) for x, y in zip(X, Y)])

    grid = torch.linspace(-0.1, 0.1, 201, dtype=torch.float64)[:, None]
    with torch.no_grad():
        posterior = gp.posterior(grid)
    assert abs(grid[posterior.mean.argmax()].item() - 0.03) < 0.01
    assert posterior.sample().shape[-2:] == (201, 1)
    with torch.no_grad():
        assert (gp.posterior(X).mean - truth).abs().max() < 0.03


def test_fit_gp_reads_trials():
    trials = [dict(theta=[x, -x], value=0.5 + x, sem=0.02) for x in torch.linspace(-0.1, 0.1, 8).tolist()]
    gp = bo.fit_gp(trials)
    with torch.no_grad():
        mean = gp.posterior(torch.tensor([[0.1, -0.1], [-0.1, 0.1]], dtype=torch.float64)).mean
    assert mean[0] > mean[1]


def test_search_defaults():
    args = bo.argument_parser().parse_args([])
    assert (args.seed, args.theta_range) == (0, None)
    assert (args.n_baseline, args.n_sobol, args.n_evals) == (8, 8, None)
    assert (search_args().tr_init, search_args().succ_tol, search_args().fail_tol) == (0.8, 3, None)


def quadratic(thetas, batch):
    """Peak at (0.05, -0.05); signal ≫ noise so the GP's pick is the best observed. One (value, sem) per row of the batch."""
    return [(1.0 - 100 * ((theta - torch.tensor([0.05, -0.05])) ** 2).sum().item(), 0.01) for theta in thetas]


def test_search_baseline_sobol_region_then_best_posterior(tmp_path):
    seen = []
    chosen = turbo.search(search_args("--n-evals", "8"), lambda t, b: seen.extend((row, b) for row in t.tolist()) or quadratic(t, b), dim=2, out=tmp_path)

    trials = json.loads((tmp_path / "trials.json").read_text())
    assert [(t["theta"], t["trial"]) for t in trials] == seen
    assert [t["baseline"] for t in trials] == [True] * 2 + [False] * 10
    assert [t["design"] for t in trials] == [True] * 4 + [False] * 8
    assert (tmp_path / "turbo.json").exists()
    assert all(t["theta"] == [0.0, 0.0] for t in trials[:2])
    assert all(-0.1 <= x <= 0.1 for t in trials[2:] for x in t["theta"])
    assert trials[2]["theta"] != trials[3]["theta"]
    assert chosen is not None and chosen["steps"] == 12
    baseline = torch.tensor([t["value"] for t in trials[:2]])
    assert chosen["baseline"] == pytest.approx(baseline.mean().item())
    assert chosen["baseline_sem"] == pytest.approx(baseline.std().item() / 2**0.5)
    assert chosen["theta"] == max(trials, key=lambda t: t["value"])["theta"]


def test_search_can_return_theta_zero(tmp_path):
    # every searched point scores below the θ=0 replicates: the honest pick is no adapter at all
    objective = lambda thetas, batch: [(1.0 - 10 * theta.abs().sum().item(), 0.02) for theta in thetas]
    chosen = turbo.search(search_args("--n-evals", "8"), objective, 2, tmp_path)
    assert chosen is not None and chosen["theta"] == [0.0, 0.0] and chosen["baseline"]


def test_search_resumes_from_trials_json(tmp_path):
    done = [
        dict(trial=0, batch=0, design=True, baseline=True, theta=[0.0, 0.0], value=0.5, sem=0.02, length=0.8),
        dict(trial=1, batch=1, design=True, baseline=True, theta=[0.0, 0.0], value=0.6, sem=0.02, length=0.8),
        dict(trial=2, batch=2, design=True, baseline=False, theta=[0.07, -0.01], value=0.7, sem=0.02, length=0.8),
    ]
    (tmp_path / "trials.json").write_text(json.dumps(done))
    seen = []
    turbo.search(search_args(), lambda t, i: seen.append(i) or quadratic(t, i), 2, tmp_path)
    trials = json.loads((tmp_path / "trials.json").read_text())
    assert trials[:3] == done and len(trials) == 8
    assert seen == [3, 4, 5, 6, 7]


def test_search_stops_after_current_trial_on_signal(tmp_path):
    def objective(thetas, batch):
        if batch == 1:
            os.kill(os.getpid(), signal.SIGUSR1)
        return quadratic(thetas, batch)

    assert turbo.search(search_args(), objective, 2, tmp_path) is None
    assert len(json.loads((tmp_path / "trials.json").read_text())) == 2


DATASET = Dataset.from_dict({"question": ["1+1?", "4-2?", "2+2?", "3+3?"], "answer": ["2", "2", "4", "6"]})


class FakeModel(torch.nn.Module):
    """Unsloth's fast_inference model surface: `load_lora` hands out fresh ids, `fast_generate` answers per prompt."""

    def __init__(self):
        super().__init__()
        self.linear = torch.nn.Linear(3, 5, bias=False)
        self.v = torch.nn.Parameter(torch.zeros(2))
        self.calls: list[dict] = []
        self.loras: dict[int, list[float]] = {}

    def load_lora(self, save_directory, load_tensors=False):
        assert load_tensors  # from the live state_dict, as grpo.Snapshot does
        lora_id = len(self.loras) + 1
        self.loras[lora_id] = self.v.tolist()
        return types.SimpleNamespace(id=lora_id, path=save_directory)

    def fast_generate(self, prompts, sampling_params, lora_request, use_tqdm):
        requests = lora_request if isinstance(lora_request, list) else [lora_request] * len(prompts)
        assert len(requests) == len(prompts)
        self.calls.append(dict(prompts=prompts, sampling=sampling_params, lora_ids=[r.id for r in requests]))
        # a rollout is right iff the question is one of the "2" ones -> per-question pass rate 0 or 1
        return [
            types.SimpleNamespace(outputs=[types.SimpleNamespace(text=f"\\boxed{{{2 if '2?' in p else 0}}}")] * sampling_params.n)
            for p in prompts
        ]


class FakeAdapter:
    calls: dict = {}
    exports: list[dict] = []

    @staticmethod
    def attach(model, rank, seed, **kwargs):
        FakeAdapter.calls = dict(rank=rank, seed=seed, **kwargs)
        model.linear.weight.requires_grad_(False)  # only `v` stays trainable -> θ ∈ ℝ²
        return model

    @staticmethod
    def export(model, out_dir):
        Path(out_dir).mkdir(parents=True, exist_ok=True)
        (Path(out_dir) / "adapter_config.json").write_text("{}")
        FakeAdapter.exports.append(dict(dir=out_dir, theta=model.v.tolist()))


class FakeTokenizer:
    def __call__(self, text):
        return types.SimpleNamespace(input_ids=[0] * len(text.split()))

    def save_pretrained(self, out_dir):
        (Path(out_dir) / "tokenizer.json").write_text("{}")


@pytest.fixture
def stubbed(monkeypatch, tmp_path):
    model = FakeModel()
    loads: dict = {}

    def from_pretrained(**kwargs):
        loads.update(kwargs)
        return model, FakeTokenizer()

    monkeypatch.setattr(unsloth.FastLanguageModel, "from_pretrained", from_pretrained)
    monkeypatch.setitem(train_bo.TASKS, "gsm8k", lambda split: DATASET)
    monkeypatch.setattr(torch.cuda, "get_device_properties", lambda i: types.SimpleNamespace(total_memory=80 * 2**30))
    monkeypatch.setattr(torch.cuda, "max_memory_allocated", lambda: 3 * 2**30)
    monkeypatch.setattr(torch.cuda, "get_device_name", lambda i: "FakeGPU")
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(train_bo, "grpo_bases", lambda args: (Path("fake/final_adapter"), {}))
    FakeAdapter.exports.clear()
    return model, loads


def parse(*extra: str, out: str):
    base = ["--model", "qwen2.5-7b", "--task", "gsm8k", "--out", out, "--no-greedy", "--k-rollouts", "64", "--eval-tasks", "gsm8k"]
    return turbo.add_arguments(train_bo.argument_parser()).parse_args([*base, *SMALL, *extra])


def test_argument_parser_defaults():
    args = train_bo.argument_parser().parse_args(["--model", "qwen2.5-7b", "--task", "gsm8k", "--out", "o"])
    assert (args.batch, args.k_rollouts) == (1, 1)
    assert (args.n_evals, args.max_completion, args.rank, args.proj_dim) == (None, 1024, 2, 1)


def test_default_theta_range_is_grpo_max_displacement():
    # lr = 1e-3/(r·√u), 3 epochs, 64 prompts per step: 640 prompts, r=2, u=4 -> 2.5e-4 · 3 · 10
    assert train_bo.max_grpo_displacement(640, rank=2, proj_dim=4) == pytest.approx(7.5e-3)
    assert train_bo.max_grpo_displacement(65, rank=2, proj_dim=1) == pytest.approx(3e-3)


def test_grpo_steps():
    assert train_bo.grpo_steps(640) == 30 and train_bo.grpo_steps(65) == 6


def test_questions_per_theta():
    # one objective call = one GRPO step of completions, split over batch θ's × k rollouts
    completions = train_bo.grpo.PROMPTS_PER_STEP * train_bo.grpo.ROLLOUTS_PER_PROMPT
    assert train_bo.questions_per_theta(1, 1) == completions
    assert train_bo.questions_per_theta(4, 2) == completions // 8
    with pytest.raises(ValueError):
        train_bo.questions_per_theta(3, 1)


def test_run_resolves_theta_range_and_n_evals_from_dataset(stubbed, tmp_path):
    args = parse(out=str(tmp_path / "run"))
    args.theta_range = None
    args.n_evals = None
    train_bo.run(args, FakeAdapter, turbo.search, "llmbo")
    # 4 prompts -> 1 step/epoch -> 3 · 5e-4
    assert args.theta_range == pytest.approx(1.5e-3)
    assert args.n_evals == train_bo.grpo_steps(len(DATASET))
    assert json.loads((tmp_path / "run" / "run.json").read_text())["theta_range"] == pytest.approx(1.5e-3)


def test_run_wires_model_adapter_objective_and_outputs(stubbed, tmp_path):
    model, loads = stubbed
    out = tmp_path / "run"
    train_bo.run(parse(out=str(out)), FakeAdapter, turbo.search, "llmbo")
    spec = MODELS["qwen2.5-7b"]

    # same load as grpo.run, adapter attached with its kwargs
    assert loads["model_name"] == spec.hf_id
    assert loads["max_seq_length"] == 512 + 1024
    assert loads["max_lora_rank"] == 8 and loads["fast_inference"]
    assert loads["gpu_memory_utilization"] == 0.85  # BO holds no training state
    assert FakeAdapter.calls == dict(rank=2, seed=0, proj_dim=1, tie=0, bases={})  # default: one global v

    # each trial's θ lands in the model (as float32) before generation; one fresh vLLM adapter id per generation, no export
    trials = json.loads((out / "trials.json").read_text())
    assert len(trials) == 8
    rollouts = [c for c in model.calls if c["sampling"].n == 64]
    assert all(len(set(c["lora_ids"])) == 1 for c in rollouts)  # batch 1: one LoRA serves every prompt of the call
    assert torch.allclose(torch.tensor([model.loras[c["lora_ids"][0]] for c in rollouts]), torch.tensor([t["theta"] for t in trials]))
    assert model.v.dtype == torch.float32
    ids = [c["lora_ids"][0] for c in model.calls]
    assert ids == sorted(ids) and len({c["lora_ids"][0] for c in rollouts}) == len(rollouts)
    assert all(t["sem"] > 0 for t in trials)  # Beta posterior noise, no floor needed

    # objective: n questions x K rollouts, raw-text prompts with the model's stop strings
    assert all(len(c["prompts"]) == 256 // 64 for c in rollouts)  # one GRPO step of completions per call
    assert rollouts[0]["sampling"].stop == list(spec.prompt.stop)
    assert all(p.startswith("<|im_start|>system") for p in rollouts[0]["prompts"])

    # snapshots of the GP's pick after GP-guided trials 1, 2 and 4 (the last; 2 baseline + 2 Sobol are the initial design); export only at the last
    snapshots = sorted(d.name for d in (out / "snapshots").iterdir())
    assert snapshots == ["step-000001", "step-000002", "step-000004"]
    evals = [c for c in model.calls if c["sampling"].temperature == 0.0]
    assert all(len(c["prompts"]) == len(DATASET) for c in evals)
    assert 1 <= len(evals) <= 3  # an unchanged pick copies the previous snapshot instead of re-evaluating
    for name in snapshots:
        assert (out / "snapshots" / name / "trainable.safetensors").exists()
        assert json.loads((out / "snapshots" / name / "eval@1" / "summary.json").read_text())["gsm8k"]["n"] == len(DATASET)
    assert json.loads((out / "snapshots" / "step-000004" / "eval@4" / "summary.json").read_text())["gsm8k"]["samples"] == 4
    # every snapshot refreshes the final_adapter export; the run's own export of the chosen θ comes last
    assert {e["dir"] for e in FakeAdapter.exports} == {str(out / "final_adapter")} and len(FakeAdapter.exports) == len(evals) + 1

    # export: final_adapter written from the chosen θ, run.json for the dashboard
    summary = json.loads((out / "run.json").read_text())
    assert summary["theta"] in [t["theta"] for t in trials]
    assert FakeAdapter.exports[-1]["dir"] == str(out / "final_adapter")
    assert torch.allclose(torch.tensor(FakeAdapter.exports[-1]["theta"]), torch.tensor(summary["theta"]))
    assert (out / "final_adapter" / "tokenizer.json").exists()
    assert (summary["adapter"], summary["loss"], summary["steps"], summary["params"], summary["gpu"]) == ("fakeadapter", "llmbo", 8, 2, "FakeGPU")
    assert {"baseline", "baseline_logit", "baseline_logit_sem"} <= summary.keys() and 0 < summary["baseline"] < 1
    assert (summary["rank"], summary["proj_dim"], summary["tie"], summary["peak_vram_gb"]) == (2, 1, 0, 3.0)
    # --no-greedy: GRPO's rollout sampler (T=1, no top-p/k) and run.json says so
    assert summary["greedy"] is False and summary["k_rollouts"] == 64
    assert all(c["sampling"].temperature == 1.0 for c in rollouts)


def test_run_untied_concatenates_every_v(stubbed, tmp_path):
    model, _ = stubbed
    model.linear.weight.requires_grad_(True)  # a second trainable tensor: θ ∈ ℝ^(2+15)
    FakeAdapter.attach = staticmethod(lambda m, rank, seed, **kw: (FakeAdapter.calls.update(kw), m)[1])
    train_bo.run(parse("--untie", out=str(tmp_path / "run")), FakeAdapter, turbo.search, "llmbo")
    summary = json.loads((tmp_path / "run" / "run.json").read_text())
    assert FakeAdapter.calls["tie"] == 1 and summary["tie"] == 1
    assert summary["params"] == 17 and len(summary["theta"]) == 17
    assert torch.allclose(torch.cat([model.v, model.linear.weight.flatten()]), torch.tensor(summary["theta"]))


def test_run_skips_export_when_search_is_interrupted(stubbed, tmp_path, monkeypatch):
    out = tmp_path / "run"
    monkeypatch.setattr(turbo, "search", lambda *a, **k: None)
    train_bo.run(parse(out=str(out)), FakeAdapter, turbo.search, "llmbo")
    # the config half of run.json is out for the dashboard, the summary half is not
    config = json.loads((out / "run.json").read_text())
    assert "steps" not in config and config["max_steps"] == 4 and config["design"] == 4
    assert not (out / "final_adapter").exists()

